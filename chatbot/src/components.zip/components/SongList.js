import React, { useState, useEffect } from "react";

export default function SongList() {
  let [songs, setSongs] = useState(null);

  useEffect(() => {
    async function FetchData() {
      const data = await fetch("http://localhost:5000/songs");
      const response = await data.json();
      setSongs(response);
    }
    FetchData();
  }, []);

  if (songs === null) {
    return <div>Loading...</div>;
  }
  console.log(songs);
  // songs = JSON.parse(songs);
  // console.log(songs);

  return (
    <div>
      <ul>
        {songs.map((song) => (
          <li key={song["name"]}>
            <img src={song["image"][1]["#text"]} alt={song["name"]} />
            <a target="_blank" href={song["url"]}>
              {song["name"]}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
