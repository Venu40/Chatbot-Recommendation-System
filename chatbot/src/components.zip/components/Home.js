import { Card, Container, Box, Grid, Typography } from "@mui/material";
import Login from "./Login";
import SignUp from "./SignUp";
const Home = () => {
  return (
    <>
      <Grid
        container
        sx={{
          height: "80vh",
          // backgroundImage: `url(https://images.unsplash.com/photo-1512295767273-ac109ac3acfa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=435&q=80)`,
          // backgroundSize: "cover",
        }}
        alignItems="center"
        justifyContent="center"
      >
        <Grid item xs={5}>
          <Typography variant="h4">Welcome to </Typography>
          <Typography variant="h2">A12 songs App</Typography>
        </Grid>
        <Grid item xs={5}>
          <Login />
        </Grid>
      </Grid>
    </>
  );
};
export default Home;
